package com.lakahuur.keyboard

import android.inputmethodservice.InputMethodService
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout

class LakahuurKeyboardService : InputMethodService() {
    private var caps = false
    private var numbers = false

    override fun onCreateInputView(): View {
        return buildKeyboard()
    }

    private fun buildKeyboard(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(5, 8, 5, 8)
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(3, 20, 45), Color.rgb(0, 92, 145), Color.rgb(0, 35, 75))
            )
        }
        val banner = Button(this).apply {
            text = "🌊  LAKAHUUR  •  📋 PASTE"
            isAllCaps = false
            textSize = 14f
            setTextColor(Color.rgb(190, 245, 255))
            background = keyBg(true)
            setOnClickListener { handleKey("PASTE") }
        }
        root.addView(banner, rowParams(38))
        val rows = if (numbers) listOf(
            listOf("1","2","3","4","5","6","7","8","9","0"),
            listOf("@","#","$","%","&","-","+","(",")","/"),
            listOf("*","\"","'",":",";","!","?"),
            listOf("ABC","⌫","space","↵")
        ) else listOf(
            listOf("q","w","e","r","t","y","u","i","o","p"),
            listOf("a","s","d","f","g","h","j","k","l"),
            listOf("⇧","z","x","c","v","b","n","m","⌫"),
            listOf("?123",",","space",".","↵")
        )
        rows.forEach { row ->
            val line = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            row.forEach { label ->
                val b = Button(this).apply {
                    text = label
                    isAllCaps = false
                    textSize = if (label == "space") 12f else 17f
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(if (label in listOf("⇧","⌫","↵","?123","ABC")) Color.WHITE else Color.rgb(225, 250, 255))
                    background = keyBg(label in listOf("⇧","⌫","↵","?123","ABC"))
                    setPadding(0, 0, 0, 0)
                    setOnClickListener { handleKey(label) }
                }
                val weight = if (label == "space") 4f else if (label in listOf("?123","ABC","⇧","⌫","↵")) 1.35f else 1f
                line.addView(b, LinearLayout.LayoutParams(0, dp(47), weight).apply {
                    setMargins(2, 3, 2, 3)
                })
            }
            root.addView(line)
        }
        return root
    }

    private fun handleKey(key: String) {
        val ic = currentInputConnection ?: return
        when (key) {
            "PASTE" -> {
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                val clip = clipboard.primaryClip
                if (clip != null && clip.itemCount > 0) {
                    val pasted = clip.getItemAt(0).coerceToText(this)
                    if (pasted != null) ic.commitText(pasted, 1)
                }
            }
            "⌫" -> ic.deleteSurroundingText(1, 0)
            "↵" -> ic.commitText("\n", 1)
            "space" -> ic.commitText(" ", 1)
            "⇧" -> { caps = !caps; setInputView(buildKeyboard()) }
            "?123", "ABC" -> { numbers = !numbers; setInputView(buildKeyboard()) }
            else -> {
                val value = if (caps) key.uppercase() else key
                ic.commitText(value, 1)
                if (caps) { caps = false; setInputView(buildKeyboard()) }
            }
        }
    }

    private fun keyBg(accent: Boolean): GradientDrawable =
        GradientDrawable().apply {
            cornerRadius = dp(9).toFloat()
            setColor(if (accent) Color.rgb(0, 115, 170) else Color.rgb(8, 48, 82))
            setStroke(dp(1), Color.rgb(44, 190, 235))
        }

    private fun rowParams(height: Int) =
        LinearLayout.LayoutParams(-1, dp(height)).apply { bottomMargin = dp(3) }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
