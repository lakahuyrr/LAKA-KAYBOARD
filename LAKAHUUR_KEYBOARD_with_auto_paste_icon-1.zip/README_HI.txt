LAKAHUUR KEYBOARD — Blue Ocean Glow

यह Android Studio project का शुरुआती version है।
Features: QWERTY keys, shift, number/symbol toggle, backspace, space, enter, clipboard PASTE button.
यह version offline है और typed text को save या internet पर send नहीं करता। ऊपर 📋 PASTE दबाने पर Android clipboard का मौजूदा text active chat/app में paste होगा।

APK बनाने के लिए:
1. Android Studio में इस folder को Open करें।
2. Gradle sync पूरा होने दें।
3. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
4. APK app/build/outputs/apk/debug/ में बनेगा।

फोन में चालू करने के लिए:
1. LAKAHUUR KEYBOARD app खोलें।
2. Enable keyboard दबाएँ और Settings में इसे enable करें।
3. वापस आकर Select LAKAHUUR KEYBOARD दबाएँ।
4. इसे चुनें।

ध्यान दें: यह पहला basic version है; emoji/GIF panel, custom photo picker और theme editor अभी शामिल नहीं हैं।
Keyboard में private messages/passwords टाइप होते हैं, इसलिए केवल भरोसेमंद keyboard इस्तेमाल करें।

App icon: LAKAHUUR blue neon gaming PFP icon is included in Android launcher mipmap folders.
